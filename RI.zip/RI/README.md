# RRI 1. vjezba
1. Vježba iz kolegija RRI
